### What changes does this introduce?

Please describe what changes this introduces.

e.g fixes stack overflow when beeping the wrong boop.

### Explain your solution

Please explain in an understandable way how your solution works.

e.g stack was overflowing because bop 3 did not include enough vowels.

### Related issues

Let us know if this is related to any issues or discussions.
