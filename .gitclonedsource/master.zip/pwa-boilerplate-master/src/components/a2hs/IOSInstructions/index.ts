export { default } from './IOSInstructions.component';
