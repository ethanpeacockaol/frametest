export { default } from './A2HS.component';
