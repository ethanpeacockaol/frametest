export { default } from './Switch.component';
