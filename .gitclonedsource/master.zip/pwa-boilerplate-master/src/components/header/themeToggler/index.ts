export { default } from './ThemeToggler.component';
