export { default } from './Placeholder.component';
