export { default, PageItem, PageItemList } from './Pages.component';
