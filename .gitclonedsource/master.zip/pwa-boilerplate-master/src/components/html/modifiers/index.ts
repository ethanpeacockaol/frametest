export { default as Style } from './style.component';
