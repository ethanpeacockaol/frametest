export { default } from './Footer.component';
