export { default } from './Icon.component';
