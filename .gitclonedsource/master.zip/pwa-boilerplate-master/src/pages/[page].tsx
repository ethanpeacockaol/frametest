export { default } from 'routes/page';
