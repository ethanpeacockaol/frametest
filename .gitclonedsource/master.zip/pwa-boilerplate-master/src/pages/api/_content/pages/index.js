import home from './home.html';
import whyPwa from './why-pwa.html';
import getStarted from './get-started.html';

export default {
  'home': home,
  'why-pwa': whyPwa,
  'get-started': getStarted
};
