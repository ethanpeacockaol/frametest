export { default } from 'routes/pageList';
