export { default } from 'routes/profile';
