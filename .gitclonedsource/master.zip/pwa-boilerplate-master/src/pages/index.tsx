import React from 'react';
import Page from 'routes/page';

export default function Home(): JSX.Element {
  return <Page isLanding />;
}
