export { default } from './Profile.component';
