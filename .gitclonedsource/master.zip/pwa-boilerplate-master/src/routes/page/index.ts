export { default } from './Page.component';
