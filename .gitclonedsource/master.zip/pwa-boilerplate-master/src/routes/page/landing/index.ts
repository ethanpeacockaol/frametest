export { default } from './Landing.component';
